package com.minimal.notilog

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "notilog_prefs"
        private const val KEY_LANG = "app_language"
    }

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: MessageAdapter
    private lateinit var tvStatusBanner: TextView
    private lateinit var tvMessageCount: TextView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var etSearch: EditText

    private val newMsgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshMessages()
        }
    }

    override fun attachBaseContext(newBase: Context) {
        val prefs = newBase.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedLang = prefs.getString(KEY_LANG, Locale.getDefault().language) ?: "ar"
        val locale = Locale(if (savedLang == "ar") "ar" else "en")
        Locale.setDefault(locale)

        val config = Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        val localizedContext = newBase.createConfigurationContext(config)
        super.attachBaseContext(localizedContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyLayoutDirection()
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        tvStatusBanner = findViewById(R.id.tvStatusBanner)
        tvMessageCount = findViewById(R.id.tvMessageCount)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)
        etSearch = findViewById(R.id.etSearch)
        val rvMessages: RecyclerView = findViewById(R.id.rvMessages)

        adapter = MessageAdapter(
            onCopyClick = { item ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(item.sender, item.message))
                Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
            },
            onLongDeleteClick = { item ->
                dbHelper.deleteMessage(item.id)
                Toast.makeText(this, getString(R.string.deleted_item_toast), Toast.LENGTH_SHORT).show()
                refreshMessages()
            }
        )

        rvMessages.layoutManager = LinearLayoutManager(this)
        rvMessages.adapter = adapter

        // Language Toggle (Arabic RTL <-> English LTR)
        findViewById<Button>(R.id.btnLangToggle).setOnClickListener {
            toggleLanguage()
        }

        // Clear All Messages
        findViewById<Button>(R.id.btnClearAll).setOnClickListener {
            confirmClearAll()
        }

        // Status Banner click opens the 2-step Restricted Setting helper dialog
        tvStatusBanner.setOnClickListener {
            if (!isNotificationListenerEnabled()) {
                showPermissionDialog()
            }
        }

        // Live Search Filter
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                refreshMessages()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        if (!isNotificationListenerEnabled()) {
            showPermissionDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusBanner()
        refreshMessages()

        val filter = IntentFilter(WhatsAppNotificationService.ACTION_NEW_WHATSAPP_MESSAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(newMsgReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(newMsgReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(newMsgReceiver)
        } catch (_: Exception) {
        }
    }

    private fun applyLayoutDirection() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lang = prefs.getString(KEY_LANG, Locale.getDefault().language) ?: "ar"
        window.decorView.layoutDirection = if (lang == "ar") {
            View.LAYOUT_DIRECTION_RTL
        } else {
            View.LAYOUT_DIRECTION_LTR
        }
    }

    private fun toggleLanguage() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentLang = prefs.getString(KEY_LANG, Locale.getDefault().language) ?: "ar"
        val nextLang = if (currentLang == "ar") "en" else "ar"
        prefs.edit().putString(KEY_LANG, nextLang).apply()
        recreate()
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val cn = ComponentName(this, WhatsAppNotificationService::class.java)
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(cn.flattenToString())
    }

    private fun showPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.perm_dialog_title)
            .setMessage(R.string.perm_dialog_message)
            .setPositiveButton(R.string.perm_grant_btn) { _, _ ->
                openNotificationAccessSettings()
            }
            .setNeutralButton(R.string.perm_unlock_btn) { _, _ ->
                openAppDetailsSettings()
            }
            .setNegativeButton(R.string.perm_later_btn, null)
            .show()
    }

    private fun openAppDetailsSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openNotificationAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updateStatusBanner() {
        if (isNotificationListenerEnabled()) {
            tvStatusBanner.setText(R.string.status_active)
            tvStatusBanner.setBackgroundColor(Color.parseColor("#D1FAE5"))
            tvStatusBanner.setTextColor(Color.parseColor("#065F46"))
        } else {
            tvStatusBanner.setText(R.string.status_inactive)
            tvStatusBanner.setBackgroundColor(Color.parseColor("#FEE2E2"))
            tvStatusBanner.setTextColor(Color.parseColor("#991B1B"))
        }
    }

    private fun refreshMessages() {
        val query = etSearch.text?.toString() ?: ""
        val messages = dbHelper.getMessages(query)
        adapter.submitList(messages)
        tvMessageCount.text = getString(R.string.msg_count_format, messages.size)

        if (messages.isEmpty()) {
            emptyStateLayout.visibility = View.VISIBLE
        } else {
            emptyStateLayout.visibility = View.GONE
        }
    }

    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_all_title)
            .setMessage(R.string.clear_all_message)
            .setPositiveButton(R.string.delete_btn) { _, _ ->
                dbHelper.clearAll()
                refreshMessages()
                Toast.makeText(this, getString(R.string.cleared_all_toast), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel_btn, null)
            .show()
    }
}
