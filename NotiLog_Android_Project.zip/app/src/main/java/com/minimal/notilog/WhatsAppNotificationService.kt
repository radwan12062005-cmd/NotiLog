package com.minimal.notilog

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WhatsAppNotificationService : NotificationListenerService() {

    companion object {
        const val ACTION_NEW_WHATSAPP_MESSAGE = "com.minimal.notilog.NEW_WHATSAPP_MESSAGE"
        private const val PKG_WHATSAPP = "com.whatsapp"
        private const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"

        private val IGNORED_PATTERNS = listOf(
            "Checking for new messages",
            "جاري البحث عن رسائل جديدة",
            "WhatsApp Web is currently active",
            "واتساب ويب نشط حالياً",
            "Backup in progress",
            "جاري النسخ الاحتياطي",
            "Deleting messages",
            "This message was deleted",
            "تم حذف هذه الرسالة"
        )
    }

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate() {
        super.onCreate()
        dbHelper = DatabaseHelper(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        val pkg = sbn.packageName ?: return
        if (pkg != PKG_WHATSAPP && pkg != PKG_WHATSAPP_BUSINESS) {
            return
        }

        val notification = sbn.notification ?: return
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (sbn.isOngoing) return

        val extras = notification.extras ?: return
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return

        val rawText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: return

        val messageText = rawText.trim()
        if (sender.isEmpty() || messageText.isEmpty()) return
        if (shouldIgnoreNotification(sender, messageText)) return

        val timestamp = if (sbn.postTime > 0) sbn.postTime else System.currentTimeMillis()
        val isBusiness = (pkg == PKG_WHATSAPP_BUSINESS)

        val insertedId = dbHelper.insertMessageIfNew(
            sender = sender,
            message = messageText,
            timestamp = timestamp,
            isBusiness = isBusiness
        )

        if (insertedId != -1L) {
            val intent = Intent(ACTION_NEW_WHATSAPP_MESSAGE).apply {
                setPackage(packageName)
            }
            sendBroadcast(intent)
        }
    }

    private fun shouldIgnoreNotification(sender: String, message: String): Boolean {
        if (sender.equals("WhatsApp", ignoreCase = true) || sender == "واتساب") {
            return true
        }
        for (pattern in IGNORED_PATTERNS) {
            if (message.contains(pattern, ignoreCase = true)) {
                return true
            }
        }
        val summaryRegex = Regex("^\\d+\\s+(new\\s+)?messages.*", RegexOption.IGNORE_CASE)
        if (summaryRegex.matches(message)) return true

        return false
    }
}
