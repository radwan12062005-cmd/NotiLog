package com.minimal.notilog

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter(
    private val onCopyClick: (LoggedMessage) -> Unit,
    private val onLongDeleteClick: (LoggedMessage) -> Unit
) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    private val items = mutableListOf<LoggedMessage>()
    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd  hh:mm:ss a", Locale.getDefault())

    fun submitList(newItems: List<LoggedMessage>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvSender: TextView = itemView.findViewById(R.id.tvSender)
        private val tvAppTag: TextView = itemView.findViewById(R.id.tvAppTag)
        private val tvTimestamp: TextView = itemView.findViewById(R.id.tvTimestamp)
        private val tvMessageBody: TextView = itemView.findViewById(R.id.tvMessageBody)

        fun bind(item: LoggedMessage) {
            val context = itemView.context
            tvSender.text = item.sender
            tvMessageBody.text = item.message
            tvTimestamp.text = dateFormatter.format(Date(item.timestamp))
            tvAppTag.text = if (item.isBusiness) {
                context.getString(R.string.wa_business_tag)
            } else {
                context.getString(R.string.wa_personal_tag)
            }

            itemView.setOnClickListener { onCopyClick(item) }
            itemView.setOnLongClickListener {
                onLongDeleteClick(item)
                true
            }
        }
    }
}
