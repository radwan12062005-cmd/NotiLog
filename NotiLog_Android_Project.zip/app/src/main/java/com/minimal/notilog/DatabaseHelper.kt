package com.minimal.notilog

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class LoggedMessage(
    val id: Long,
    val sender: String,
    val message: String,
    val timestamp: Long,
    val isBusiness: Boolean
)

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "notilog_local.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_MESSAGES = "whatsapp_messages"
        const val COL_ID = "id"
        const val COL_SENDER = "sender"
        const val COL_MESSAGE = "message"
        const val COL_TIMESTAMP = "timestamp"
        const val COL_IS_BUSINESS = "is_business"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_MESSAGES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_SENDER TEXT NOT NULL,
                $COL_MESSAGE TEXT NOT NULL,
                $COL_TIMESTAMP INTEGER NOT NULL,
                $COL_IS_BUSINESS INTEGER DEFAULT 0
            )
        """.trimIndent()
        db.execSQL(createTable)
        db.execSQL("CREATE INDEX idx_timestamp ON $TABLE_MESSAGES($COL_TIMESTAMP DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MESSAGES")
        onCreate(db)
    }

    fun insertMessageIfNew(sender: String, message: String, timestamp: Long, isBusiness: Boolean): Long {
        val db = writableDatabase
        val deduplicationWindowMs = 15_000L
        val cursor = db.query(
            TABLE_MESSAGES,
            arrayOf(COL_ID),
            "$COL_SENDER = ? AND $COL_MESSAGE = ? AND ABS($COL_TIMESTAMP - ?) < ?",
            arrayOf(sender, message, timestamp.toString(), deduplicationWindowMs.toString()),
            null,
            null,
            null,
            "1"
        )
        val alreadyExists = cursor.use { it.moveToFirst() }
        if (alreadyExists) return -1L

        val values = ContentValues().apply {
            put(COL_SENDER, sender)
            put(COL_MESSAGE, message)
            put(COL_TIMESTAMP, timestamp)
            put(COL_IS_BUSINESS, if (isBusiness) 1 else 0)
        }
        return db.insert(TABLE_MESSAGES, null, values)
    }

    fun getMessages(searchQuery: String = ""): List<LoggedMessage> {
        val list = mutableListOf<LoggedMessage>()
        val db = readableDatabase

        val selection: String?
        val selectionArgs: Array<String>?
        if (searchQuery.isBlank()) {
            selection = null
            selectionArgs = null
        } else {
            selection = "$COL_SENDER LIKE ? OR $COL_MESSAGE LIKE ?"
            val pattern = "%${searchQuery.trim()}%"
            selectionArgs = arrayOf(pattern, pattern)
        }

        val cursor = db.query(
            TABLE_MESSAGES,
            null,
            selection,
            selectionArgs,
            null,
            null,
            "$COL_TIMESTAMP DESC"
        )

        cursor.use { c ->
            val idIdx = c.getColumnIndexOrThrow(COL_ID)
            val senderIdx = c.getColumnIndexOrThrow(COL_SENDER)
            val msgIdx = c.getColumnIndexOrThrow(COL_MESSAGE)
            val timeIdx = c.getColumnIndexOrThrow(COL_TIMESTAMP)
            val bizIdx = c.getColumnIndexOrThrow(COL_IS_BUSINESS)

            while (c.moveToNext()) {
                list.add(
                    LoggedMessage(
                        id = c.getLong(idIdx),
                        sender = c.getString(senderIdx),
                        message = c.getString(msgIdx),
                        timestamp = c.getLong(timeIdx),
                        isBusiness = c.getInt(bizIdx) == 1
                    )
                )
            }
        }
        return list
    }

    fun deleteMessage(id: Long) {
        writableDatabase.delete(TABLE_MESSAGES, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun clearAll() {
        writableDatabase.delete(TABLE_MESSAGES, null, null)
    }
}
